clear
ls /etc/netclear
clear
/etc/netwoks/interfaces
/etc/network/interfaces
nano /etc/network/interfaces
cat /etc/networks/interfaces
nano  /etc/networks/interfaces
clear
nano  /etc/networks/interfaces
nano /etc/networks/interfaces
clea
clear
nano /etc/networsk/interfaces
nano /etc/networks/interfaces
clear
nano /etc/networks/interfaces
clear
clear
nano /etc/networks/interfaces
nano /etc/network/interfaces
clear
apt update
clear
nano /etc/network/interfaces
clear
apt update
systemctl reboot network
clear
apt update
clear
nano /etc/network/interfaces
clear
systemactl  restart network
systemactl  restart networks
systemactl restart networks
systemactl restart network
clear
systemactl network restart
systemactl networks restart
clear
system restart networking
systemctl restart networking
celar
clear
clear
shutdown now
clear
ip -a
clear
ip a
ping 192.168.56.1
ping 192.168.56.1
clear
apt update
clear
nano /etc/network/interfaces
clear
systemctl restart networking
clear
apt update
clear
ipconfig
clear
ip a
192.168.56.1
ping 192.168.56.1
ping 192.168.56.2
ping 192.168.56.3
ping 192.168.56.4
ping 192.168.56.1
ping 192.168.0.1
clear
shutdown now
clear
nano /etc/network/interfaces
clear
systemctl restart networking
clear
systemctl restart networking
systemctl restart network
clear
nano /etc/network/interfaces
clear
systemctl restart networking
clear
ip a
clear
nano /etc/network/interfaces
clear
systemctl restart networking
clear
ip a
nano /etc/network/interfaces
clear
systemctl restart networking
clear
ip a
nano /etc/network/interfaces
clear
systemctl restart networking
cat /root/ssh/id_rsa
cls
clear
cls
cleas
cls
clear
rm -f /root/.ssh/authorized_keys
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
cleas
clear
shutdown now
vi /etc/network/interfaces
clear
nano /etc/apt/sources.list
clear
nano /etc/apt/sources.list
clear
clear
ls /etc | grep "hostname"
clear
ls /etc | grep "hostname"
clear
nano /etc/hostname
clear
shutdown now -r
shutdown now
vi /etc/network/interfaces
clear
nano /etc/network/interfaces
lear
clear
systemctl restart networking
clear
ping google.com
clear
ping 10.129.0.5
clear
apt update
nano /etc/network/interfaces
cleaar
clear
ping google.com
apt update
clear
nano /etc/network/interfaces
clear
apt update
clear
nano /etc/network/interfaces
clear
cat /etc/network/interfaces
clear
apt update
reboot
clear
apt update
clear
apt install openssh-server
clear
version
cat version
clear
nano /ssh/sshd_config
nano /etc/ssh/sshd_config
clear
mkdir -p /root/.ssh
mkdir -p /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
clear
vim /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
CLEAR
clear
cat /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
clear
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
clear
systemctl status ssh
ip a
clear
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
ip a
clear
nano /etc/ssh/sshd_config
reboot
clear
systemctl restart ssh
reboot
clear
nano /etc/network/interfaces
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
clear
ls
ls -l
cls
cls
clear
clear
cls
cls
clear
ip a
clear
ip a
clear
nano /etc/ssh/sshd_config
clear
shutdown now
clear
lsblk
clear
fdisk /dev/sdc
clear
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
clear
mkdir  /www_dir /backup_dir
clear
blkid
clear
nano /etc/fstab
clear
nano /etc/fstab
clear
mount -a
systemctl daemon-reload
clear
mount -a
df -h
clear
apt update
clear
apt install apache2 -y
clear
apt install php libapache2-mod-php -y
clear
cp /root/index.php /var/www/html/
ip a
clear
ip a
clear
ls /root
clear
ls /root
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
systemctl restart apache2
systemctl restart apache2
systemctl restart apache2
systemctl restart apache2
systemctl restart apache2
systemctl restart apache2
clear
apt update
clear
apt install mariadb-server -y
clear
sudo mysql_secure_installation
clear
sudo mysql_secure_installation
clear
systemctl stop mariadb
apt purge mariadb-server mariadb-client -y
clear
rm -rf /etc/mysql
rm -rf /var/lib/mysql
apt autoremove -y
clear
apt update
clear
apt install mariadb-server -y
systemctl status mariadb
reboot
ip a
clear
systemctl status mariadb
clear
apt install mariadb-server
dpkg --configure -a
apt-get install -f
dpkg --configure -a
apt --fix-broken install
clear
sudo apt install mariadb-server
clear
ip a
clear
reboot
clear
ip a
clear
nano /etc/network/interfaces
clear
reboot
clear
apt install mariadb-server
clear
ls -l /etc/mysql
clear
touch /etc/mysql/mariadb.cnf
ls -l /etc/mysql
clear
dpkg --configure -a
apt --fix-broken install
clear
apt install mariadb-server
clear
systemctl status mariadb
clear
mysql_secure_installation
clear
mysql
clear
ls /root
ls /root/Material_Adicional_TPVMCA.tar.gz 
clear
ls /root
clear
ls /root
clear
mysql < /root/db.sql
clear
mysql
cklear
clear
lsblk
clear
cat /etc/apache2/sites-available/000-default.conf | grep DocumentRoot
clear
Trabajo práctico integrador grupal   
Consignas  
Condiciones generales 
a) Este trabajo práctico se debe realizar en una máquina virtual con GNU/Linux 
Debian preinstalado, que se encuentra disponible, para su descarga, en 
Blackboard. La máquina virtual ya está configurada específicamente para esta 
actividad, y debe importarse como un sistema virtualizado. 
Las instrucciones para la importación se encuentran en el sitio web de Oracle 
VirtualBox. 
b) Grupos: los equipos de trabajo no deben exceder los 5 integrantes, y deben estar 
registrados en Blackboard. 
c) Calificación: para aprobar, es necesario tener el 60% del trabajo práctico bien y 
funcionando. Asimismo, se deberá realizar la defensa oral en modalidad sincrónica 
sobre las tareas realizadas. 
1) Configuración del entorno 
1) La máquina virtual está dividida en partes y comprimidas en formato “.rar”. 
Descargar y ensamblar los archivos utilizando herramientas como WinRar.  
2) La clave de root es desconocida inicialmente, por lo que deberá ser blanqueada 
antes de comenzar. Una vez dentro del sistema operativo, la misma debe ser 
cambiada por “palermo” (sin comillas). 
3) Establecer el nombre de hostname como TPServer. 
2) Servicios 
1) Actualizar SO: actualizar la distribución del sistema operativo completamente a 
Debian 12.  
2) SSH: instalar y configurar el servicio de SSH. El servidor debe permitir el acceso al 
usuario root mediante una clave privada/pública, disponible dentro del Home de 
root. 
© Universidad de Palermo. Prohibida la reproducción total o parcial de imágenes y textos. 
1 
3) Web: instalar y configurar el servidor Apache con soporte para PHP (versión 7.3 o 
superior). Configurar el servidor para servir el archivo “index.php” y “logo.png”, 
disponible dentro del Home de root.  
4) Base de datos: instalar y configurar MariaDB. Cargar, en el motor de base de 
datos, el script SQL, denominado “db.sql”, disponible dentro del Home de root. 
Nota: las pruebas de conectividad y acceso al sitio web deben realizarse desde una 
máquina física u otra máquina en la misma red. 
3) Configuración de red 
1) Configurar la interfaz de red con una IP estática en el archivo de configuración. La 
IP debe pertenecer al mismo rango red de la máquina física. 
2) El archivo de configuración debe incluir los campos ADDRESS, NETMASK Y 
GATEWAY.  
4) Almacenamiento 
1) Agregar un nuevo disco de 10 GB adicional a la máquina virtual. 
2) Crear dos particiones estándar (tipo 83), con las siguientes capacidades: 
 /www_dir: 3 GB  
 /backup_dir: 6 GB 
3) Configurar el directorio /www_dir para alojar el archivo index.php y logo.png.  
Actualizar el archivo de configuración de Apache para que éste apunte a la nueva 
ubicación (ver archivos 000-default.conf y apache2). 
4) Configurar el directorio /www_dir para que se monte automáticamente al iniciar 
el sistema operativo.  
5) Configurar el directorio /backup_dir para que se monte automáticamente al iniciar 
el sistema operativo.  
Nota: se debe crear un archivo en /opt, llamado "particion", y redirigir el contenido del 
archivo "partitions", ubicado en /proc (el archivo original es efímero y se pierde al apagar 
la máquina).  
© Universidad de Palermo. Prohibida la reproducción total o parcial de imágenes y textos. 
2 
5) Backup  
1) Desarrollar un script de backup denominado “backup_full.sh”, y guardarlo en 
/opt/scripts.  
2) El script debe backupear los directorios indicados con nombres que incluyan la 
fecha en formato ANSI (YYYMMDD). Por ejemplo, para /var/log, el archivo 
generado debería llamarse “log_bkp_20240302.tar.gz”. 
3) Los backups generados deben almacenarse en la partición que tiene montado el 
directorio /backup_dir. 
4) El script debe aceptar argumentos como origen (lo que se va a backupear) y 
destino (dónde se va a backupear). 
5) El script debe incluir una opción de ayuda (-help), para guiar al usuario en el uso 
del script.  
6) El script debe validar que los sistemas de archivos de origen y destino estén 
disponibles antes de ejecutar el backup. 
7) El script debe ser incluido en un calendario de tareas para correr 
automáticamente: 
 TODOS LOS DÍAS a las 00:00 hs: Backupear “/var/logs” 
 LUNES, MIÉRCOLES, VIERNES a las 23:00 hs: Backupear “/www_dir” 
6) Entregables 
1) Crear un repositorio en github (es gratuito), y redactar el README.md con los 
nombres de los participantes del grupo.  
2) Subir, en el repositorio creado, los directorios: 
 “/root”, “/etc”, “/opt”,  “/www_dir” y “/backup_dir”. Todos ellos 
comprimidos individualmente en formato “.tar.gz”. 
 “/var” se lo debe splitear en partes pequeñas para que pueda ser subido.  
clear
ls /root
cp /root/index.php /www_dir/
cp /root/logo.png /www_dir/
cp /root/index.php /www_dir/
cp /root/logo.png /www_dir/
ls /www_dir/
clear
ls /www_dir/
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
celar
clear
ls /www_dir
clear
nano /etc/fstab
clear
nano /etc/fstab
lsblk
clear
systema restart apache2
systemctl restart apache2
clear
clear
cat /proc/partitions > /opt/particion
cat /opt/particion
clear
systema restart apache2
clear
systemctl restart apache2
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
clear
systemctl status apache2
clear
ls -l /www_dir
clear
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
systemctl status apache2 --no-pager
ls -l /www_dir
clear
curl http://localhost
clear
ls -ld /www_dir
cat /www_dir/index.php | head
curl http://localhost/index.php
apache2ctl -S
grep -R "<Directory" /etc/apache2
clear
nano /etc/apache2/apache2.conf
clear
systemctl restart apache2
clear
ip a
clear
clear
ls /opt
clear
mkdir -p /opt/scripts
clear
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
clear
nano /opt/scripts/backup_full.sh
clear
ip a
shutdown now
