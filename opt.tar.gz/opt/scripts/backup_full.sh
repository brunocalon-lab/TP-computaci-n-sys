#!/bin/bash

# ==========================================
# OPCIÓN DE AYUDA (-help)
# ==========================================


if [ "$1" == "-help" ]; then
    echo "Uso del script: ./backup_full.sh [ORIGEN] [DESTINO]"
    echo "Ejemplo: ./backup_full.sh /var/log /backup_dir"
    exit 0
fi


# ==========================================
# VALIDACIÓN DE ARGUMENTOS
# ==========================================


if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: Faltan argumentos. Uso: ./backup_full.sh [ORIGEN] [DESTINO]"
    echo "Ejecutá './backup_full.sh -help' para más información."
    exit 1
fi


# Se guardan los argumentos...
ORIGEN=$1
DESTINO=$2

# ==========================================
# VALIDACIÓN DE DIRECTORIO
# ==========================================


if [ ! -d "$ORIGEN" ]; then
	    echo "Error: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi



# Validamos que el destino sea un punto de montaje activo.

if ! mountpoint -q "$DESTINO"; then
    echo "Error: El destino '$DESTINO' no está disponible o no es un punto de montaje activo."
    exit 1
fi



# ==========================================
# COMPRESIÓN Y FORMATO ANSI
# ==========================================

FECHA=$(date +%Y%m%d)


NOMBRE_BASE=$(basename "$ORIGEN")


NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando el proceso de empaquetado..."
echo "Origen: $ORIGEN"
echo "Destino: ${DESTINO}/${NOMBRE_ARCHIVO}"
echo "-------------------------------------------"

# Ejecutamos el comando TAR...
tar -czf "${DESTINO}/${NOMBRE_ARCHIVO}" "$ORIGEN" 2>/dev/null

# Verificación
if [ $? -eq 0 ]; then
    echo "¡Proceso finalizado con éxito!"
    echo "Archivo generado: ${NOMBRE_ARCHIVO}"
    exit 0
else
    echo "Error: Ocurrió un fallo al intentar compilar el .tar.gz"
    exit 1
fi
